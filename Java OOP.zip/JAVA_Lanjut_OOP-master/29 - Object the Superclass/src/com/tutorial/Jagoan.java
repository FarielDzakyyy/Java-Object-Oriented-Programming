package com.tutorial;

public class Jagoan {
    private String name;

    public Jagoan(String name){
        this.name = name;
    }

    public void display(){
        System.out.println("\nName: " + this.name);
    }
}
