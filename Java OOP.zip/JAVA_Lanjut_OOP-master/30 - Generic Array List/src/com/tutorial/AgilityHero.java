package com.tutorial;

public class AgilityHero extends Hero{

    AgilityHero(String name, double health){
        super(name, health);
    }
    
}
