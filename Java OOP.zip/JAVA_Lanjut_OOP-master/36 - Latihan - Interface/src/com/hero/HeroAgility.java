package com.hero;

public class HeroAgility extends Hero{

	public HeroAgility(String name, double health){
		super(name,health);
	}
	
}
