package com.tutorial;

public class Hero {
    String name;

    void display(){
        System.out.println("hero name: " + this.name);
    }
}