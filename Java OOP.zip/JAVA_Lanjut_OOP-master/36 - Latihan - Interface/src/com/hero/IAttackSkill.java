package com.hero;

public interface IAttackSkill {
	void attack(Hero enemy);
}
