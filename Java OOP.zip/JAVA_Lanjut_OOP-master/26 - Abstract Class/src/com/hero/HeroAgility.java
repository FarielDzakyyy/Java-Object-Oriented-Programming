package com.hero;

// inheritance dari abstract Hero
public class HeroAgility extends Hero{
	
	public HeroAgility(String name){
		super(name);
	}
}