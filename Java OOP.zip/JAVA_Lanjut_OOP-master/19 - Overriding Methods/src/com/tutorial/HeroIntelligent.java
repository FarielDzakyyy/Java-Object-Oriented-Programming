package com.tutorial;

public class HeroIntelligent extends Hero{
    
}