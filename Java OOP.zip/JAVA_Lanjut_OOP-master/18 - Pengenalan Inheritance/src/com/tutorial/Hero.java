package com.tutorial;

// superclass, parent class, base class
class Hero{
    String name;

    // method
    void display(){
        System.out.println("Name : " + this.name);
    }
}