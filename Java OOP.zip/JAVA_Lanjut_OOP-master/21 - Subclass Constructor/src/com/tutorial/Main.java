package com.tutorial;

class Main{
    public static void main(String[] args) {
        HeroStrength hero1 = new HeroStrength("Naruko",50,10);
        hero1.display();
    }
}