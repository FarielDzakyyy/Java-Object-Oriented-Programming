package com.terminal;

public class Console {
    public static void log(String message){
        System.out.println(message);
    }
}