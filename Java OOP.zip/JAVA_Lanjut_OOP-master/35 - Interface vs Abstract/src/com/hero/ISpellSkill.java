package com.hero;

public interface ISpellSkill {
	void spell(Hero enemy);
}
