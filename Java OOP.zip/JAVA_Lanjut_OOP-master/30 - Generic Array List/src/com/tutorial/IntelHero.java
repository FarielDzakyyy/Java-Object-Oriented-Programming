package com.tutorial;

public class IntelHero extends Hero{

    IntelHero(String name, double health){
        super(name, health);
    }
    
}
