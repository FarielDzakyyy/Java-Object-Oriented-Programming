package com.tutorial;

// subclass, child class, derived class
class HeroStrength extends Hero{
    // hampa
}