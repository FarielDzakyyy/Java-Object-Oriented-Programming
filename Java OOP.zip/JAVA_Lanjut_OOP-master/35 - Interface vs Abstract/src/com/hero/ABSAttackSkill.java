package com.hero;

public abstract class ABSAttackSkill {
	abstract void attack(Hero enemy);
}
